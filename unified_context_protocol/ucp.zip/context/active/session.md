# Active Session State
> **WARNING**: This file is the "Live Brain" of the current agent session. 
> Agents must update this file constantly to persist their state.

## 🎯 Current Focus
- [ ] (Agent: Write your current immediate goal here)

## 📝 Scratchpad (Plans & Notes)
(Agent: Dump your reasoning, step-by-step plans, and temporary findings here. Do not keep them in internal memory.)

## 🛑 Blockers / Questions
- (List anything stopping you)
