# Change Log

> Running log of all changes. Newest first.

---

## [DATE]

### Initial Setup
- Created `.ai/` context system
- Ready for first audit

---

*Add new entries above this line*
