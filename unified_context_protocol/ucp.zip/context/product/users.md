# User Personas

> **Know Your Customer (KYC)**

## User A: [The Ideal Customer]
- **Role**: *e.g., Content Creator*
- **Pain Points**:
  1. *Doesn't have time to write*
  2. *Fears inconsistency*
- **Motivations**: *Growth, Money, Fame*
- **Tech Savviness**: *Low/Medium/High*

## User B: [The Secondary User]
- **Role**: *e.g., Agency Owner*
- **Pain Points**: ...

## User Journey Map
1. **Discovery**: *How they find us*
2. **Onboarding**: *First 5 minutes*
3. **Usage**: *Daily workflow*
4. **Upgrade**: *Moving to paid plan*
