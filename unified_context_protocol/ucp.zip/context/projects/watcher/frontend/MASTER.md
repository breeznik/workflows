# Watcher Frontend Context

> **Scoped Context for: Watcher > Frontend**

## Current State
| Area | Status | Notes |
|------|--------|-------|
| UI | 🔴 Broken | 500 errors on load |
