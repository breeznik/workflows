# Agent Learnings

> Memory of what works and fails in this specific project.
> Updated by agents over time. Reviewed during maintenance.

## ✅ What Works

<!-- Add entries using this format:
### [Topic]
**Discovered:** YYYY-MM-DD | **Confidence:** high/medium/low
- Details
-->

*Add learnings above this line.*

---

## ❌ What Failed

<!-- Add entries using this format:
### [Topic]
**Discovered:** YYYY-MM-DD | **Confidence:** high/medium/low
- What went wrong
- How to avoid
-->

*Add failures above this line.*

---

## 🔄 Superseded

> Old learnings that are no longer accurate. Kept for reference.

*Move outdated learnings here instead of deleting.*
