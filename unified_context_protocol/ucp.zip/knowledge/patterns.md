# Code Patterns

> Document recurring patterns used in this codebase.
> Use tags for searchability.

## Template

### [Pattern Name]
**Tags:** `tag1`, `tag2`  
**Where:** Where is this pattern used?

**How:** How to implement it?

```language
// Example code
```

**Why:** Why use this pattern?

---

## Patterns

*Add patterns above this line using the template.*
