# Gotchas

> Things that can trip you up in this codebase.
> Use tags for searchability.

## Template

### [Gotcha Title]
**Tags:** `tag1`, `tag2`  
**Severity:** high | medium | low

**Symptom:** What goes wrong?

**Cause:** Why does it happen?

**Solution:** How to fix or avoid it?

---

## Known Gotchas

*Add gotchas above this line using the template.*
